#!/bin/bash

while true; do
	xsetroot -name "🔋$(acpi -b | awk '{print $4}' | sed s/,//) |||  🗓️$(date +%b%d' ||| ''🕟'%k:%M)"
#	sleep 1m
done 

#bat=$(cat /sys/class/power_supply/BAT0/capacity)
#time=$(date +%b%d%k:%M'🕟')

#echo $bat 
#$bat+$time=all
#while true; do
#	xsetroot -name $bat $time
#	sleep 10m
#done &

