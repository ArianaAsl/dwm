#!/bin/bash
while true; do
	xsetroot -name "$(date +%b%d%k:%M'🕟')"
	sleep 1m
done &


