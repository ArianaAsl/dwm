#!/bin/bash

sxhkd &
