#!/bin/bash

#while true; do
#	xsetroot -name "$(date +%b%d%k:%M'🕟')"
#	sleep 1m
#done &

bat=$(cat /sys/class/power_supply/BAT0/capacity)

#echo $bat 🔋

while true; do
	xsetroot -name $bat''🔋
	sleep 1m
done &
